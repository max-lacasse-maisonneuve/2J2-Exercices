using UnityEngine;
using UnityEngine.InputSystem;

public class DeplacementVoiture : MonoBehaviour
{
    public float vitesseDeplacement = 7.5f;
    public float vitesseRotation = 150;

    float inputTourner;
    float inputAccelerer;


    void Update()
    {        
        // Appliquer la rotation et le d�placement selon l'intensit� des entr�es
        transform.Rotate(0,0,vitesseRotation * Time.deltaTime * inputTourner);
        transform.Translate(0f, vitesseDeplacement * Time.deltaTime * inputAccelerer, 0f, Space.Self);
    }
}
