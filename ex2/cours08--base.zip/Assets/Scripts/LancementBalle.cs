using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class LancementBalle : MonoBehaviour
{
    public InputAction inputBalle;
    public float vitesseMin, vitesseMax, acceleration;
    public Image barreFront;
    public GameObject uiBarre;

    private float vitesse;
    private Rigidbody2D rb;

    private void OnEnable()
    {
        inputBalle.Enable();
    }

    private void OnDisable()
    {
        inputBalle.Disable();
    }

    void Start()
    {
        vitesse = 0;
        uiBarre.SetActive(false);
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        // Ajouter la condition n�cessaire pour activer le if le 1er frame quand la touche
        // barre d'espace ou le bouton gauche de la souris sont enfonc�s
        //if ()
        //{
        //    uiBarre.SetActive(true);
        //    barreFront.fillAmount = 0;
        //    vitesse = vitesseMin;
        //}

        // Ajouter la condition n�cessaire pour activer le if tous les frames o� la touche
        // barre d'espace ou le bouton gauche de la souris sont enfonc�s
        //if ()
        //{
        //    vitesse += acceleration * Time.deltaTime;
        //    barreFront.fillAmount = (vitesse - vitesseMin) / (vitesseMax - vitesseMin);
        //}

        // Ajouter la condition n�cessaire pour activer le if le 1er frame quand la touche
        // barre d'espace ou le bouton gauche de la souris sont rel�ch�s
        //if ()
        //{
        //    vitesse = Mathf.Clamp(vitesse, vitesseMin, vitesseMax);
        //    rb.linearVelocityY = vitesse;
        //    vitesse = 0;
        //    uiBarre.SetActive(false);
        //}


        if (inputBalle.WasPressedThisFrame())
        {
            rb.linearVelocityY = vitesseMax * 0.6f;
            vitesse = 0;
        }
    }
}
